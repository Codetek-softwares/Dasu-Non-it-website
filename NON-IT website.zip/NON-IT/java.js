document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    const responseMessage = `Name: ${name}\nEmail: ${email}\nMessage: ${message}`;

    // Display response in a pop-up message
    alert(responseMessage);

    // Display response in chat box
    const chatBox = document.getElementById('chatBox');
    const chatMessage = document.createElement('div');
    chatMessage.classList.add('chat-message');
    chatMessage.textContent = responseMessage;
    chatBox.appendChild(chatMessage);

    // Clear the form
    document.getElementById('contactForm').reset();
});
